<?php

return [
    'required' => 'Input :attribute wajib diisi ya kaka.',
    'confirmed' => 'Password konfirmasi tidak cocok kaka.',
    'email' => 'Email harus yang valid eaaa.',
    'array' => 'Yang beneng dorr',
    'image' => 'Jangan coba coba usil ya kaka, :attribute harus gambar.',
    'max' => [
        'string' => ':attribute nya kelebihan dong, jangan melebihi :max karakter.',
    ],
    'min' => [
        'string' => 'Kurang dong :attribute nya, harus :min karakter.',
    ],
    'password' => 'Password nya salah.',
    'unique' => ':attribute sudah ada, ganti yang lain aja ya',
];
