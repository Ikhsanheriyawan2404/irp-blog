<?php

return [
    'failed' => 'Gagal! email atau password salah.',
    'password' => 'Password nya salah',
];
